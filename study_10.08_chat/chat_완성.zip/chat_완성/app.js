var express = require('express');
var http = require('http');
var app = express();
var request = require('request');
var server = http.createServer(app).listen(81);
var mysql = require('mysql');
var io = require('socket.io').listen(server);
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({limit: '50mb', extended: false}));
app.use(bodyParser.json({limit: '50mb'}));

var connection = mysql.createConnection({
	host: 'localhost'
	, port: 3306
	, user: 'root'
	, password: '112213'
	, database: 'test'
});

//https://codepen.io/tecib71241/pen/YzyrLrG
//var users = [{userName:"aa", socketId:"bbb"}];
var users = [];
io.on('connection', function(socket){
	socket.on('joinRoom', function(userName){
		socket.join("chatRoom");
		users.push({userName:userName, socketId:socket.id});
		socket.broadcast.to("chatRoom").emit('newUserConnected', userName);
	});

	socket.on('sendMsg', function(msg){
		socket.broadcast.to("chatRoom").emit('getMsg', msg);
	});

	socket.on('disconnect', function(){
		for(var i=0;i<users.length;i++) {
			var user = users[i];
			if(user.socketId==socket.id) {
				socket.broadcast.to("chatRoom").emit('userDisconnected', user.userName);
				users.splice(i, 1);
				break;
			}
		}
	});
});


app.get('/', function (req, res) {
	res.sendfile('chat.html');
});
app.get('/chat', function (req, res) {
	res.sendfile('chat.html');
});

app.post('/login', function (req, res) {
	var userName = req.body.userName;
	for(var i=0;i<users.length;i++) {
		if(users[i].userName==userName) {
			res.send("exist");
			return;
		}
	}
	res.send("login");
});

app.get('/getChatHistory', function (req, res) {
	var selectQ = 'select * from chatHistroy';
	connection.query(selectQ,
		function (err, rows, fields) {
			if (err) throw err;
		}
	);
});

app.get('/getConnectedUsersInfo', function (req, res) {
	res.send(users);
});
